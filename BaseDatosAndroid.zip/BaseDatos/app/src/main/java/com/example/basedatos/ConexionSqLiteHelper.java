package com.example.basedatos;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class ConexionSqLiteHelper extends SQLiteOpenHelper {
    final String CREAR_TABLA="CREATE TABLE usuarios(id Integer,nombre Text, tlf Text)"; //esas variables estan relacionadas
                                                                                        //con mi clase usuario

    public ConexionSqLiteHelper( Context context,  String name,  SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREAR_TABLA); //aqui creamos la tabla
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
    db.execSQL("DROP TABLE IF EXISTS usuarios");
    onCreate(db);

    }
}
