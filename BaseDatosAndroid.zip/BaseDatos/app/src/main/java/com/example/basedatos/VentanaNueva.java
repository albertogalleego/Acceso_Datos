package com.example.basedatos;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;

import java.util.ArrayList;

public class VentanaNueva extends AppCompatActivity {

    private Cursor cursor;
    private RecyclerView usuariosvista;
    private ArrayList<Usuario> usuarioList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ventana_nueva);
        usuariosvista = findViewById(R.id.usuariosVista);

        // Inicializa la lista de usuarios
        usuarioList = new ArrayList<>();

        ConexionSqLiteHelper conexion = new ConexionSqLiteHelper(this, "misUsuarios", null, 1);
        SQLiteDatabase db = conexion.getWritableDatabase();
        cursor = db.rawQuery("SELECT * FROM usuarios", null);

        while (cursor.moveToNext()) {
            int idc = cursor.getInt(0);
            String nombreC = cursor.getString(1);
            String tlfC = cursor.getString(2);

            Usuario nuevoUsuario = new Usuario(idc, nombreC, tlfC);
            usuarioList.add(nuevoUsuario);
        }

        // Inicializamos el adaptador y lo rellenamos con la lista
        aadaptador alumnoaAdaptador = new aadaptador(this, usuarioList);

        // Configuramos el RecyclerView con un LinearLayoutManager
        LinearLayoutManager lym = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        usuariosvista.setLayoutManager(lym);

        // Configuramos el OnClickListener para el adaptador
        alumnoaAdaptador.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Aquí puedes manejar los eventos de clic en los elementos de la lista
            }
        });


        // Establecemos el adaptador en el RecyclerView
        usuariosvista.setAdapter(alumnoaAdaptador);
    }
}
