package com.example.basedatos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.net.wifi.p2p.WifiP2pManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    Button btn,intent;
    EditText id, nombre, tlf;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn = findViewById(R.id.btn);
        id = findViewById(R.id.id);
        intent=findViewById(R.id.intent);
        nombre = findViewById(R.id.nombre);
        tlf = findViewById(R.id.tlf);
        btn.setOnClickListener(this);
        intent.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn:

                //este va a ser la base de datos con nombre de la base de datos misUsuarios, null porque si y version 1xd

                ConexionSqLiteHelper con = new ConexionSqLiteHelper(this, "misUsuarios", null, 1);

                //con ese con creamos el conector y ya podemos ejecutar el oncreate si no existe el oncreate no se crea la tabla
                SQLiteDatabase db = con.getWritableDatabase();

                //el contentvalues almacena los campos de nuestra tabla es como si fuera un registro, es como si fuera una estructura
                //de memoria
                ContentValues contenedor = new ContentValues();
                //Ahora para guardar cosas usamos un
                contenedor.put("id", Integer.parseInt(id.getText().toString()));
                contenedor.put("nombre", nombre.getText().toString());
                contenedor.put("tlf", tlf.getText().toString());
                long result = db.insert("usuarios", "id", contenedor);
                Toast.makeText(this, "Resultado de la inserción: " + Long.toString(result), Toast.LENGTH_SHORT).show();

                //el metodo insert nos devuelve un long que nos da el resultado de la insercion
                //por ello creamos la tabla usuarios, ponemos un id como calve primaria y el objeto contenedor pasamos todo que hemos
                // creado con id,nombre,tlf

                break;

            case R.id.intent:
            Intent nuevo= new Intent(this,VentanaNueva.class);
            startActivity(nuevo);
            break;

        }
    }
}