package com.example.basedatos;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;

public class aadaptador extends RecyclerView.Adapter<aadaptador.ViewHolder> {

    private Context context;
    private ArrayList<Usuario> usuarioList;
    private View.OnClickListener listener;

    public aadaptador(Context context, ArrayList<Usuario> usuarioList) {
        this.context = context;
        this.usuarioList = usuarioList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Usuario usuario = usuarioList.get(position);
        holder.idusuario.setText(String.valueOf(usuario.getId()));
        holder.nombreusuario.setText(usuario.getNombre());
        holder.tlfusuario.setText(usuario.getTlf());
    }

    @Override
    public int getItemCount() {
        return usuarioList.size();
    }

    public void setOnClickListener(View.OnClickListener listener) {
        this.listener=listener;
    }


    public static class ViewHolder extends RecyclerView.ViewHolder {
        private TextView idusuario, nombreusuario, tlfusuario;
        private ImageView imageView;

        public ViewHolder(View itemView) {
            super(itemView);
            idusuario = itemView.findViewById(R.id.idusuario);
            nombreusuario = itemView.findViewById(R.id.nombreusuario);
            tlfusuario = itemView.findViewById(R.id.tlfusuario);
            imageView = itemView.findViewById(R.id.imageView);
        }
    }
}
